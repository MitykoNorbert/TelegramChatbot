# Üdv a TelegramChatbot alkalmazásomban!

Ezzel a ChatBottal Python nyelven valósítottam meg az üzeneten keresztüli időpont foglalásokat egy demo rendszerbe.
##A projekt a TelegramChatbotProject-ben található.
## Szükséges csomagok:
- python-telegram-chatbot - 13.7
- `requirements.txt` -ben találhatóak részletesebben
- `pip install -r requirements.txt` paranccsal lehet a szükséges csomagokat telepíteni.

## A beüzemeltetéshez szükséges tennivalók: 
- Az `api_key.py` file tartalmát kell módosítani, ha a saját chatbotodat szeretnéd kezelni
- Ezzel a verzióval az én saját, `@helperbot509_bot` chatbotot lehet futtatni.

## Package telepítése:
- `pip install TelegramChatbotProject`
