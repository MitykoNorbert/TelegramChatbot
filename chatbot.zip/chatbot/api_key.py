"""
Ez a modul tartalmazza a telegram bot működéséhez szükséges
API Kulcsot, amit a telegram rendszeréből kapunk a bot
létrehozásakor.
"""
API_KEY = '6154049059:AAHlqaL1PV4qeoX8iudz-5CfzsHce4CunN8'
